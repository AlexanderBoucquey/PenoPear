function [ R_q ] = Rq( r,l )       
       R_q= l/6*[2*r(1)+r(2); r(1)+2*r(2)];
            
end